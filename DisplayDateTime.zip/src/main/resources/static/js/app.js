if (confirm("This is the " + document.title.toLocaleLowerCase() +" template")) {
  txt = "You pressed OK";
} else {
  txt = "You pressed Cancel";
}