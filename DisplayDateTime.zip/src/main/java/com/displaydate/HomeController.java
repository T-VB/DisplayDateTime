package com.displaydate;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

//create Controller for
@Controller
public class HomeController {
	@RequestMapping("/")
	public String index(Model model) {
		return "index.jsp";
	}
	
	@RequestMapping("/date") 
	public String date(Model model) {
		//create an for EACH parameter (dayname, day, month, year)
		SimpleDateFormat dayNameFormat = new SimpleDateFormat("EEEE");
		SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
		SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
		SimpleDateFormat yearFormat = new SimpleDateFormat("Y");
		
		//create new date instance, to use as an argument for EACH string
		Date date = new Date();
		
		//create an object for EACH String
		String dayNameString = dayNameFormat.format(date);
		String dayString = dayFormat.format(date);
		String monthString = monthFormat.format(date);
		String yearString = yearFormat.format(date);
		
		//create instance of dateString, adding all the previous instances of date String
		String dateString = dayNameString + dayString + monthString + yearString;
		
		//adding dateString to our model
		model.addAttribute("dateString", dateString);
		
		return "date.jsp";
	}
	
	@RequestMapping("/time")
	public String time(Model model) {
		SimpleDateFormat format = new SimpleDateFormat("h:mm a");
		
		//create new date instance, to use as an argument for timeString
		Date date = new Date();
		
		//create instance timeString with date as an argument
		String timeString = format.format(date);
		
		//adding timeString to model
		model.addAttribute("timeString", timeString);
		
		return "time.jsp";
		
	}
	
}
